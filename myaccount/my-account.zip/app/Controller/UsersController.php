<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
App::uses('CakeEmail', 'Network/Email');
class UsersController extends AppController {

    public $uses= array('Customer', 'User', 'Nextusa', 'MasterBillingGroup', 'BillingGroup', 'Subscriber', 'Cdr', 'OriginationRoute', 'VendorOriginationRoute', 'FraudCtrlPref', 'CreditControll');
    
    public function beforeFilter() {
        set_time_limit(0);
        parent::beforeFilter();

    }

    public function index() {
        $this->autoRender = false;
        $this->redirect('/');
    }
    
    public function login() {
        $this->layout = 'login';
        if ($this->request->is('post')) {
            if ($this->Auth->login()) {
                $this->redirect($this->Auth->redirect());
            } else {
                $this->Session->setFlash(__('Invalid username or password, try again'));
            }
        }
    }

    public function dashboard() {
        $this->layout = 'client';
    }

    public function billing() {
        $this->layout = 'client';
        $userData = $this->Session->read('Auth');
        
        $s_field = 'id';
        $s_value = $userData['User']['id'];
        //*****************************************WHMCS API
        $postfields["action"] = "getclientsdetails";
        if ($s_field == "id")
            $postfields["clientid"] = $s_value;
        else if ($s_field == "email")
            $postfields["email"] = $s_value;

        
        $clientDetail = $this->whmcsInvoker($postfields);
        sleep(2);
        $clientDetail = $clientDetail['WHMCSAPI'];

        if ($clientDetail['RESULT'] == 'success') {

            $this->Session->write("clientDetails", $clientDetail);

            $query = "Select * from tblinvoices where userid='" . $userData['User']['id'] . "' ORDER BY date DESC";

            $billingData = $this->remoteData($query);

            if ($billingData['status'] == "success") {  //billing data found
                $this->Session->write("clientbillingHistory", $billingData);
            }

        } else {
            $this->Session->setFlash(__('No data related to this user.'));
        }
        
        $this->autoRender = true;
        $this->set('clients', $this->Session->read('clients'));
        $this->set('clientDetails', $this->Session->read('clientDetails'));
        $this->set('clientBillingHistory', $this->Session->read('clientbillingHistory'));
    }

    public function changeClientStatusInWHMCS() {
        $this->autoRander = false;
        if ($this->request->is('ajax') && ($this->clientIdPresent())) {
            $currentClient = $this->Session->read('clientDetails');
            $postfields["action"] = "updateclient";
            $postfields["clientid"] = $currentClient['CLIENT']['ID'];
            $postfields["status"] = $this->request->data['status'];
            $status = $this->whmcsInvoker($postfields);
            if ($status['WHMCSAPI']['RESULT'] == 'success') {
                $response['done'] = true;
                $currentClient['CLIENT']["STATUS"] = $this->request->data['status'];
                $this->Session->write('clientDetails',$currentClient);
            } else {
                $response['done'] = false;
            }
            echo json_encode($response);
        }
    }

    public function pbx() {
        $this->layout = 'client';
    }

    public function provisioning() {
        $this->layout = 'client';
        $this->set('title_for_layout', 'Provisioning');
        $this->set('devceBrand', $this->Brandmodel->query("SELECT distinct brand from brandmodels"));
        $this->set('frendlyname', $this->Brandmodel->find("list", array('fields' => 'FriendlyName', 'conditions' => array('Brandmodel.Brand' => 'polycom'))));
        $currentClient = $this->Session->read('clientDetails');
        $macaddresseses = $this->Macid->find("all", array('fields' => array('MacId', 'id'), 'conditions' => array('Macid.AccountID' => $currentClient['CLIENT']['ID']/* change for online file */), 'order' => 'Macid.id ASC'));
        $this->set('bolPhonesProvisioned', false);
        if (count($macaddresseses) != 0) {
            $mac_ad_count = 0;
            $mac_adresses = array();
            foreach ($macaddresseses as $macarray):
                $mac_adresses[$mac_ad_count++] = $macarray['Macid'];
            endforeach;
            
            //************all phonerelated data*************
            $phoneData = $this->Phonedata->find('all', array('fields' => array('Field', 'Data', 'ButtonNum', 'MacID'), 'conditions' => array('Phonedata.MacID BETWEEN ? AND ?' => array($macaddresseses[0]['Macid']['id'], $macaddresseses[count($macaddresseses) - 1]['Macid']['id']), 'Phonedata.ButtonNum' => '0'), 'order' => 'Phonedata.MacID ASC'));


            $reclength = count($phoneData);
            if ($reclength != 0) {      // data for each MACID **********************
                $global_button_num = 0;
                for ($i = 0; $i < $reclength; $i++) {//phone global buttons*********
                    $global_phone_buttons[$global_button_num][$phoneData[$i]['Phonedata']['Field']] = $phoneData[$i]['Phonedata']['Data'];
                    if (($i + 1) % 6 == 0 && $i != 0) {
                        $global_phone_buttons[$global_button_num]['MacId'] = $phoneData[$i]['Phonedata']['MacID'];
                        $global_button_num++;
                    }
                }
            }

            $num = 0;
            foreach ($mac_adresses as $mac_data):
                $host = $this->Phonedata->find('list', array('fields' => array('Data'), 'conditions' => array('Phonedata.MacID' => $mac_data['id'], 'Phonedata.ButtonNum' => '1', 'Phonedata.Field' => array('ExtensionNumber', 'Host')), 'order' => 'Phonedata.id ASC'));
                $host = array_values($host);
                if (!empty($host)) {
                    $mac_adresses[$num]['ExtensionNumber'] = $host['0'];
                    $mac_adresses[$num]['Host'] = $host['1'];
                } else {
                    $mac_adresses[$num]['ExtensionNumber'] = "";
                    $mac_adresses[$num]['Host'] = "";
                }
                $num++;
            endforeach;

            $num = 0;

            foreach ($global_phone_buttons as $global):
                $brandmodel = $this->Brandmodel->find('first', array('fields' => array('FriendlyName', 'Brand'), 'conditions' => array('Brandmodel.id' => $global['BrandModels.id'])));
                $global_phone_buttons[$num]['FriendlyName'] = $brandmodel['Brandmodel']['FriendlyName'];
                $global_phone_buttons[$num++]['Brand'] = $brandmodel['Brandmodel']['Brand'];
            endforeach;

            $this->set('bolPhonesProvisioned', true);
            $this->set('mac_id_add_ext_host', $mac_adresses);
            $this->set('global_for_each_mac', $global_phone_buttons);
            $this->set('host_address', $host);
        }
    }

    public function changeStdToArray($obj) {
        $this->autoRender = false;
        return get_object_vars($obj);
    }

    public function saveTotalDeviceConfig() {
        $this->autoRender = false;
        if ($this->request->is('ajax')) {
            $phone_data_to_save = json_decode($_POST['values']);
            $count = 0;
            while (!empty($phone_data_to_save->$count)) {
                $count++;
            }
            $this->Phonedata->query("update  phonedatas set Data='" . $phone_data_to_save->registrations . "' where Field='Registrations' and MacID='" . $phone_data_to_save->mac_id . "';");
            $this->Phonedata->query("update  phonedatas set Data='" . $phone_data_to_save->timezone . "' where Field='DateTimeZone' and MacID='" . $phone_data_to_save->mac_id . "';");
            $this->Phonedata->query("update  phonedatas set Data='" . $phone_data_to_save->localport . "' where Field='LocalPort' and MacID='" . $phone_data_to_save->mac_id . "';");

            for ($i = 0; $i < $count; $i++) {

                if ($i < $phone_data_to_save->previous_reg) { 
                    $this->Phonedata->query("update  phonedatas set Data='" . addslashes($phone_data_to_save->$i->appearances) . "' where Field='Apperances' and MacID='" . $phone_data_to_save->mac_id . "' and ButtonNum='" . ($i + 1) . "';");
                    $this->Phonedata->query("update  phonedatas set Data='" . $phone_data_to_save->$i->extension . "' where Field='ExtensionNumber' and MacID='" . $phone_data_to_save->mac_id . "' and ButtonNum='" . ($i + 1) . "';");
                    $this->Phonedata->query("update  phonedatas set Data='" . addslashes($phone_data_to_save->$i->password) . "' where Field='Secret' and MacID='" . $phone_data_to_save->mac_id . "' and ButtonNum='" . ($i + 1) . "';");
                    $this->Phonedata->query("update  phonedatas set Data='" . addslashes($phone_data_to_save->$i->host) . "' where Field='Host' and MacID='" . $phone_data_to_save->mac_id . "' and ButtonNum='" . ($i + 1) . "';");
                } else {

                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $phone_data_to_save->mac_id . "','" . ($i + 1) . "','Apperances','" . addslashes($phone_data_to_save->$i->appearances) . "');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $phone_data_to_save->mac_id . "','" . ($i + 1) . "','ExtensionNumber','" . $phone_data_to_save->$i->extension . "');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $phone_data_to_save->mac_id . "','" . ($i + 1) . "','Secret','" . addslashes($phone_data_to_save->$i->password) . "');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $phone_data_to_save->mac_id . "','" . ($i + 1) . "','Host','" . addslashes($phone_data_to_save->$i->host) . "');");
                }
            }
            if ($phone_data_to_save->previous_reg > $count) {
                while ($phone_data_to_save->previous_reg > $count) {

                    $this->Phonedata->query("DELETE FROM  phonedatas WHERE MacID = '" . $phone_data_to_save->mac_id . "' AND ButtonNum = '" . ($phone_data_to_save->previous_reg--) . "';");
                }
            }
        }
        $response['status'] = 'success';
        echo json_encode($response);
    }

    public function sendProvisionedDevices() {
        $this->autoRender = false;
        //***********extracting phone data of provisioned phones******************************
        //*********macaddress related to this account******************************************
        if ($this->request->is('ajax')) {

            $currentClient = $this->Session->read('clientDetails');
            $macaddresseses = $this->Macid->find("all", array('fields' => array('MacId', 'id'), 'conditions' => array('Macid.AccountID' => $currentClient['ID']/* change for online file */), 'order' => 'Macid.id ASC'));
            $this->set('phonesProvisioned', false);
            if (count($macaddresseses) != 0) {
                $mac_ad_count = 0;
                $mac_adresses = array();
                foreach ($macaddresseses as $macarray):
                    $mac_adresses[$mac_ad_count++] = $macarray['Macid'];
                endforeach;

                //*************brnad model ids from phonedata*******
                $brandmodelids = $this->Phonedata->find('list', array('fields' => array('Data'), 'conditions' => array('Phonedata.MacID BETWEEN ? AND ?' => array($mac_adresses[0]['id'], $mac_adresses[count($macaddresseses) - 1]['id']), 'Phonedata.Field' => 'BrandModels.id'), 'order' => 'Phonedata.Data ASC'));
                $brandmodelids = array_values($brandmodelids);

                //*************phone models related to above ids *****************
                $brandmodels = $this->Brandmodel->find('list', array('fields' => array('FriendlyName', 'Brand'), 'conditions' => array('Brandmodel.id BETWEEN ? AND ?' => array($brandmodelids[0], $brandmodelids[count($brandmodelids) - 1]))));

                //************all phonerelated data*************
                $phoneData = $this->Phonedata->find('all', array('fields' => array('Field', 'Data', 'ButtonNum', 'MacID'), 'conditions' => array('Phonedata.MacID BETWEEN ? AND ?' => array($macaddresseses[0]['Macid']['id'], $macaddresseses[count($macaddresseses) - 1]['Macid']['id']), 'Phonedata.ButtonNum' => '0'), 'order' => 'Phonedata.ButtonNum ASC'));
                //debug($phoneData);      exit;
                $reclength = count($phoneData);
                if ($reclength != 0) {      // data for each MACID **********************
                    $global_button_num = 0;
                    for ($i = 0; $i < $reclength; $i++) {//phone global buttons*********
                        $global_phone_buttons[$global_button_num][$phoneData[$i]['Phonedata']['Field']] = $phoneData[$i]['Phonedata']['Data'];
                        if (($i + 1) % 6 == 0 && $i != 0) {
                            $global_phone_buttons[$global_button_num]['MacId'] = $phoneData[$i]['Phonedata']['MacID'];
                            $global_button_num++;
                        }
                    }
                }

                $frendly_models = $brandmodels;
                $mac_id_addresses = $mac_adresses;
                $global_for_each_mac = $global_phone_buttons;
                $response = "";
                $mac_count = 0;
                foreach ($frendly_models as $p_frndlyname => $p_model):
                    $response.='<a href="#" onclick="alert(\'under process\')">[Delete]</a> <a href="#" id="22" onclick="show_window(\''
                            . $p_model . " " . $p_frndlyname . '\',\'' . $mac_id_addresses[$mac_count]["MacId"] . '\','
                            . '\'' . $mac_id_addresses[$mac_count]["id"] . '\','
                            . '\'' . $global_for_each_mac[$mac_count]["Registrations"] . '\',\'' . $global_for_each_mac[$mac_count]['LocalPort'] . '\');">[Edit]</a>'
                            . $p_model . " " . $p_frndlyname . ' - MAC Address:' . $mac_id_addresses[$mac_count++]["MacId"] . '</br>';
                endforeach;
                echo $response;
            }
            else
                echo '<span> Devices Not Provisioned Yet </span>';
        }
    }

    public function sendPhoneInfoRelatedToEachMac() {
        $this->autoRender = false;
        if ($this->request->is('ajax')) {
            $phoneData = $this->Phonedata->find('all', array('fields' => array('Field', 'Data', 'ButtonNum'), 'conditions' => array('Phonedata.MacID' => $this->request->data['macid'], 'NOT' => array('Phonedata.ButtonNum' => '0')), 'order' => 'Phonedata.MacID ASC'));
            $reclength = count($phoneData);
            $response['status'] = false;
            if ($reclength != 0) {
                $response['status'] = true;
                for ($i = 0, $local = array(); $i < $reclength; $i++) {
                    $phonedetails[$phoneData[$i]['Phonedata']['ButtonNum']][$phoneData[$i]['Phonedata']['Field']] = $phoneData[$i]['Phonedata']['Data'];
                }
                $response['phoneDetail'] = $phonedetails;
                echo json_encode($response);
            }
            else
                echo json_encode($response);
        }
    }

    public function savePhone() {
        $this->autoRender = false;
        if ($this->request->is('ajax')) {

            $currentClient = $this->Session->read('clientDetails');
            $this->request->data['Macid']['AccountID'] = $currentClient['CLIENT']['ID'];
            $this->request->data['Macid']['MacID'] = $this->request->data['macid'];

            $phone = $this->Macid->find('first', array('conditions' => array('macid' => $this->request->data['Macid']['MacID'], 'accountid' => $this->request->data['Macid']['AccountID'])));
            $response['status'] = 'alreadysaved';
            $response['message'] = 'Already Provisioned';
            if ($phone == '') {
                if ($this->Macid->SaveAll($this->request->data)) {
                    $mac_id = $this->Macid->id;
                    $id = $this->Brandmodel->find('first', array('fields' => array('id'), 'conditions' => array('Brandmodel.FriendlyName' => $this->request->data['frendlyname'], 'Brandmodel.Brand' => $this->request->data['brand'])));
                    $brandmodelid = $id['Brandmodel']['id']; //brandmodel.id
                    
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $mac_id . "','0','BrandModels.id','" . $brandmodelid . "');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $mac_id . "','0','MacID.AccountID','" . $this->request->data['Macid']['AccountID'] . "');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $mac_id . "','0','DateTimeZone','-5.0');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $mac_id . "','0','DisplayName','MyPhone');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $mac_id . "','0','LocalPort','');");
                    $this->Phonedata->query("insert into  phonedatas (MacID,ButtonNum,Field,Data) values('" . $mac_id . "','0','Registrations'," . $this->request->data['registrations'] . ");");

                    $response['Macid'] = $mac_id;
                    $response['userid'] = $currentClient['CLIENT']['ID'];
                    $response['status'] = 'success';
                    echo json_encode($response);
                } else {
                    $response['message'] = 'Failed TO Provision';
                    echo json_encode($response);
                }
            } else {
                echo json_encode($response);
            }
        }
    }

    public function sendFriendlyNames() {
        $this->autoRender = false;
        if ($this->request->is('ajax')) {

            $fname = $this->Brandmodel->find("list", array('fields' => 'FriendlyName', 'conditions' => array('Brandmodel.Brand' => $this->request->data['brand'])));
            echo json_encode($fname);
        }
    }

    public function deleteDeviceWithMacId() {
        $this->autoRender = false;

        if ($this->Macid->deleteAll(array('id' => $_POST['mac_id']), FALSE, FALSE)) { //2 other argus cascading,callback 
            $this->Phonedata->deleteAll(array('MacID' => $_POST['mac_id']), FALSE, FALSE);
            echo 'Deleted Successfully.';
        } else {
            echo 'Can Not Delete Now. Try Again.';
        }
    }

    public function deleteDetailsOfMacId() {
        $this->autoRender = false;
        if ($this->request->is('ajax')) {
            $response['success'] = false;
            $old_regs = $this->request->data['old_registrations'];
            $new_regs = $this->request->data['new_registrations'];
            $mac_id = $this->request->data['mac_id'];
            $this->Phonedata->query("update  phonedatas set Data='" . $new_regs . "' where Field='Registrations' and MacID='" . $mac_id . "';");
            while ($old_regs >= $new_regs && $old_regs != 0) {
                $this->Phonedata->query("DELETE FROM  phonedatas WHERE MacID = '" . $mac_id . "' AND ButtonNum = '" . ($old_regs--) . "';");
            }
            $response['success'] = true;
            echo json_encode($response);
        }
    }


    public function store() {
        $this->layout = 'adminDefault';
    }

    public function support() {
        $this->layout = 'adminDefault';
    }


    public function logout() {
        $this->redirect($this->Auth->logout());
    }

    public function remoteData($query) {
        $this->autoRender = false;
         /** ONLINE DATABASE */
          
        $db_host = 'localhost';
        $db_username = 'VoipLionU1';
        $db_password = 'cde$33MC';
        $db_name = 'itaki_whmcs';
         
        $con = mysql_connect($db_host, $db_username, $db_password) or die(mysql_error() . ' in line ' . __LINE__);
        mysql_select_db($db_name, $con) or die(mysql_error() . ' in line ' . __LINE__);
        $result = mysql_query($query) or die(mysql_error() . ' in line ' . __LINE__);

        $i = 0;
        $data['status'] = 'error';
        if (mysql_num_rows($result) != 0) {
            $data['status'] = 'success';
        }
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {

            $data[$i++] = $row;
        }
        
        mysql_close($con);
        return $data;
    }

    public function whmcsInvoker($postfields) {
        $this->autoRender = false;

        $url = 'http://devweb.itaki.net/clients/includes/api.php';

        $postfields["username"] = 'vladmin';
        $postfields["password"] = '750de8cc22b9573340b4548365adc6ab';
        
        /*         * ** WHMCS XML API Sample Code *** */
        $postfields["stats"] = true;
        $postfields["responsetype"] = "xml";
        //debug($postfields); exit;
        $query_string = "";
        foreach ($postfields AS $k => $v)
            $query_string .= "$k=" . urlencode($v) . "&";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $xml = curl_exec($ch);
        
        if (curl_error($ch) || !$xml)
            $xml = '<whmcsapi><result>error</result>' .
                    '<message>Connection Error</message><curlerror>' .
                    curl_errno($ch) . ' - ' . curl_error($ch) . '</curlerror></whmcsapi>';
        curl_close($ch);

        $data = $this->whmcsapi_xml_parser($xml);
        return ($data);

    }
    
    function whmcsapi_xml_parser($rawxml) {
        $this->autoRender = false;
        $xml_parser = xml_parser_create();
        xml_parse_into_struct($xml_parser, $rawxml, $vals, $index);
        xml_parser_free($xml_parser);
        $params = array();
        $level = array();
        $alreadyused = array();
        $x = 0;
        foreach ($vals as $xml_elem) {
            if ($xml_elem['type'] == 'open') {
                if (in_array($xml_elem['tag'], $alreadyused)) {
                    $x++;
                    $xml_elem['tag'] = $xml_elem['tag'] . $x;
                }
                $level[$xml_elem['level']] = $xml_elem['tag'];
                $alreadyused[] = $xml_elem['tag'];
            }
            if ($xml_elem['type'] == 'complete') {
                $start_level = 1;
                $php_stmt = '$params';
                while ($start_level < $xml_elem['level']) {
                    $php_stmt .= '[$level[' . $start_level . ']]';
                    $start_level++;
                }
                $php_stmt .= '[$xml_elem[\'tag\']] = $xml_elem[\'value\'];';
                @eval($php_stmt);
            }
        }
        return($params);
    }
}

?>
