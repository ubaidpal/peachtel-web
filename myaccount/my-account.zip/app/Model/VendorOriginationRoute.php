<?php

class VendorOriginationRoute extends AppModel {
    
    var $name = 'VendorOriginationRoute';
    var $actsAs = array('Containable');
    var $useTable = "vendor_orig_route";
    var $useDbConfig = "postgres";
    
}